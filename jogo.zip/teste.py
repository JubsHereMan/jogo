from time import sleep

string = "ola, eu sou o julio"

for letra in string:
    print(letra)
    sleep(0.2)