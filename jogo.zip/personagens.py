# personagens.py

jubs = {
    'nome': 'Jubs',
    'classe': 'mago',
    'vida': 40,
    'mana': 100,
    'dano': 8,
    'inimigos mortos': 0,
    'tipo de energia': 'Negativo',
    'nivel': 1
}

seth = {
    'nome': 'Seth',
    'classe': 'velocista',
    'vida': 50,
    'mana': 50,
    'dano': 10,
    'inimigos mortos': 0,
    'nivel': 1
}

low = {
    'nome': 'Low',
    'classe': 'spider',
    'vida': 45,
    'mana': 60,
    'dano': 9,
    'inimigos mortos': 0,
    'nivel': 1
}
